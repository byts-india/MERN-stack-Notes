export default function Footer() {
  return (
    <div className='px-10 pt-5 flex justify-around items-baseline bg-[#9e3a44] min-h-[10vh] text-white'>
        <section className="m-4 p-2">
            <h4 className="font-extrabold uppercase text-3xl">About me</h4>
            <p className="w-86 pl-0 p-2">
                Lorem, ipsum dolor sit amet consectetur adipisicing elit. Necessitatibus quia veniam perferendis,
                Lorem, ipsum dolor sit amet consectetur adipisicing elit. Necessitatibus quia veniam perferendis,
            </p>
        </section>
        <section className="m-4 p-2">
            <h4 className="font-extrabold uppercase text-3xl">Project details</h4>
            <p className="w-86 pl-0 p-2">
                Lorem, ipsum dolor sit amet consectetur adipisicing elit. Necessitatibus quia veniam perferendis,
                Lorem, ipsum dolor sit amet consectetur adipisicing elit. Necessitatibus quia veniam perferendis,
            </p>
        </section>
        <section className="m-4 p-2">
            <h4 className="font-extrabold uppercase text-3xl">Other links</h4>
            <ol className="p-2 pl-0">
                <li>About me</li>
                <li>contact</li>
                <li>Project details</li>
            </ol>
        </section>
    </div>
  )
}
