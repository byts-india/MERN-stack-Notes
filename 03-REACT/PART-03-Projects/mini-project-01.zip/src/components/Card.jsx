import { useContext } from "react";
import TodoContext from "../context/TodoContext";

function Card({ id = 0, title = "default title", desc = "default desc" }) {
    const { handleDelete, handleEdit } = useContext(TodoContext);
    
    return (
        <div className="shadow-gray-600 shadow-md min-w-96 bg-slate-300 p-5 px-10 border-2 border-white rounded-sm">
            <h3 className="uppercase font-semibold">{id + 1}.{title}</h3>
            <p className="text-gray-600 p-2">{desc}</p>
            <div className="flex justify-end">
                <button className="active:shadow-sm shadow-md px-5 p-2 rounded-sm bg-orange-200 ml-2" onClick={() => handleEdit(id)}>edit</button>
                <button className="active:shadow-sm shadow-md px-5 p-2 rounded-sm bg-red-300 ml-2" onClick={() => handleDelete(id)}>delete</button>
            </div>
        </div>
    );
}
export default Card;