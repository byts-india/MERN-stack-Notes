import React, { useContext } from 'react'
import AuthContext from '../context/AuthContext'
import { Link, useNavigate } from 'react-router-dom';
import Swal from 'sweetalert2';

export default function Header() {
    const { user, isLoggedIn, logout } = useContext(AuthContext);
    const navigate = useNavigate();

    function handleClick() {
        if (isLoggedIn) {
            Swal.fire({
                icon: "success",
                title: "Successfully logged out",
                text: "Come back to application soon. "
            });
            logout();
        }
        else
            navigate('/login');
    }

    return (
        <header className='sticky top-0 p-5 min-h-[10vh] bg-[#2a2a2a] text-white flex justify-between'>
            <div className='uppercase'>
                <Link to="/">welcome to todo app</Link>
            </div>
            <div>
                <div>{user}</div>
            </div>
            <div className='bg-[#9e3a44] px-5 p-1 cursor-pointer rounded-sm' onClick={handleClick}>
                {isLoggedIn ? 'logout' : 'login'}
            </div>
        </header>
    )
}