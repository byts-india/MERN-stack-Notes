import { createContext, useContext, useEffect, useState } from "react";
import storageService from "../services/storageService";
import AuthContext from "./AuthContext";

const TodoContext = createContext();

function TodoProvider({ children }) {
    const [title, setTitle] = useState("");
    const [desc, setDesc] = useState("");
    const [items, setItems] = useState([]);

    const { user } = useContext(AuthContext);

    useEffect(() => {
        const data = storageService.getData();
        setItems(data.items[user] ?? []);
    }, []);

    useEffect(() => {
        // do save
        if (items.length !== 0) {
            const data = storageService.getData();
            data.items[user] = items;
            storageService.saveData(data);
        }
    }, [items]);

    function handleAdd() {
        if (title.trim() != "" && desc.trim() != "") {
            let obj = {
                title: title,
                desc: desc
            };
            items.push(obj);
            setItems([...items]);
            setTitle("");
            setDesc("");
        }
    }

    function handleDelete(idx) {
        let temp = [];
        for (let i = 0; i < items.length; i++) {
            if (i != idx)
                temp.push(items[i]);
        }
        setItems(temp);
    }

    function handleEdit(idx) {
        let newTitle = prompt("enter new title");
        let newDesc = prompt("enter new desc");
        if (newTitle != null && newTitle.trim() != "" &&
            newDesc != null && newDesc.trim() != "") {
            let temp = [];
            for (let i = 0; i < items.length; i++) {
                if (i == idx) {
                    let obj = {
                        title: newTitle,
                        desc: newDesc
                    };
                    temp.push(obj);
                }
                else temp.push(items[i]);
            }
            setItems(temp);
        } else {
            alert("Invalid data");
        }
    }

    return (
        <TodoContext.Provider value={{
            title,
            setTitle,
            desc,
            setDesc,
            items,
            setItems,
            handleAdd,
            handleDelete,
            handleEdit
        }}>
            {children}
        </TodoContext.Provider>
    );
}

export default TodoContext;
export { TodoProvider };