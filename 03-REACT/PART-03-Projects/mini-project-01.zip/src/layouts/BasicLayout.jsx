import { Outlet } from 'react-router-dom'
import Header from '../components/Header'
import Footer from '../components/Footer'

export default function BasicLayout() {
    return (
        <div className='font-mono text-black min-h-screen'>
            <Header />
            <div className='min-h-[90vh] bg-[#ece9e0] p-10'>
                <Outlet />
            </div>
            <Footer />
        </div>
    )
}
