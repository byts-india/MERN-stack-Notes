import { Link } from "react-router-dom";

export default function HomePage() {
  return (
    <div>
      <section className="w-1/2">
        <h1 className="font-extrabold text-5xl uppercase">welcome to our application</h1>
        <p className="pl-0 p-5">Lorem ipsum dolor sit, amet consectetur adipisicing elit. Enim aliquid nihil omnis iste suscipit? Dolores debitis atque minima deserunt ab id, a deleniti ut exercitationem at similique doloribus ad accusamus?</p>
        <div className="bg-[#9e3a44] text-white p-2 px-4 w-fit rounded-md mt-10">
          <Link to="/login">  get started </Link>
        </div>
      </section>
    </div>
  )
}
