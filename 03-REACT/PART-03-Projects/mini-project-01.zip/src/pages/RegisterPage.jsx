import { useContext, useRef } from 'react'
import { Link, useNavigate } from 'react-router-dom';
import AuthContext from '../context/AuthContext';
import Swal from 'sweetalert2';

// uncontrolled component
export default function RegisterPage() {
    const { signUp } = useContext(AuthContext);
    const emailRef = useRef();
    const passRef = useRef();
    const navigate = useNavigate();

    function handleSubmit(event) {
        event.preventDefault();
        const email = emailRef.current.value;
        const password = passRef.current.value;
        const result = signUp(email, password);
        if (result) {
            Swal.fire({
                icon: "success",
                title: "Register successful",
                text: "New user has been created",
            });
            navigate('/login');
        } else {
            Swal.fire({
                icon: "error",
                title: "Register failed",
                text: "email Already exists",
            });
        }
    }

    return (
        <div className='w-full flex flex-col justify-center items-center'>
            <form onSubmit={handleSubmit} className='bg-white shadow-md shadow-gray-600 w-80 p-10 rounded-md h-96'>
                <h1 className='uppercase text-center mb-10 font-extrabold text-red-800 text-1xl'>Create a new Account</h1>
                <section className='flex flex-col justify-center items-center'>
                    <input
                        ref={emailRef}
                        className='p-2 m-2 mb-1 rounded-sm bg-gray-200'
                        type="email"
                        placeholder='📩 Email'
                        required
                    />
                    <input
                        ref={passRef}
                        className='p-2 m-2 mb-1 rounded-sm bg-gray-200'
                        type="password"
                        placeholder='🔒 *******'
                        required
                    />
                </section>
                <section className='flex justify-around  gap-2 mt-5'>
                    <button className='cursor-pointer p-2 px-10  rounded-sm text-white bg-red-400 shadow-md hover:shadow-sm w-auto' type='submit'>create</button>
                    <button className='cursor-pointer p-2 px-10 rounded-sm text-white bg-red-400 shadow-md hover:shadow-sm w-auto' type='reset'>reset</button>
                </section>
                <div className='text-xs mt-5 text-center text-gray-500'>
                    Already have an account ? <Link to="/login" className='text-blue-500 underline capitalize'>log in.</Link>
                </div>
            </form>
        </div>
    )
}
