import { useContext } from "react";
import Card from "../components/Card";
import TodoContext from "../context/TodoContext";

function TodoPage() {
    const {
        title,
        setTitle,
        desc,
        setDesc,
        items,
        handleAdd,
    } = useContext(TodoContext);

    return (
        <main className="w-[90vw] flex justify-baseline items-start gap-10">
            <section className="min-h-[60vh] w-1/3 bg-white shadow-lg shadow-gray-400 p-10 pb-5 px-20 rounded-lg">
                <input
                    className="bg-black text-white p-2 m-1 rounded-sm w-70"
                    value={title}
                    onChange={(e) => setTitle(e.target.value)}
                    type="text"
                    placeholder="Enter title"
                />
                <br />
                <textarea
                    className="bg-black text-white p-2 m-1 rounded-sm w-70"
                    rows={5}
                    value={desc}
                    onChange={(e) => setDesc(e.target.value)}
                    type="text"
                    placeholder="Enter desc"
                />
                <br />
                <button
                    onClick={handleAdd}
                    className="bg-green-300 float-end rounded-sm px-10 p-1 capitalize"
                >
                    add
                </button>
            </section>
            <section className="w-2/3 gap-5 flex flex-wrap">
                {
                    items.map((value, index) => {
                        return <Card
                            key={index}
                            id={index}
                            title={value.title}
                            desc={value.desc}
                        />;
                    })
                }
            </section>
        </main>
    );
}
export default TodoPage;