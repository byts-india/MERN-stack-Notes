import { useContext, useRef } from 'react'
import { Link, useNavigate } from 'react-router-dom';
import AuthContext from '../context/AuthContext';
import Swal from 'sweetalert2';

// uncontrolled component
export default function LoginPage() {
    const { login } = useContext(AuthContext);
    const navigate = useNavigate();

    const emailRef = useRef();
    const passRef = useRef();

    function handleSubmit(event) {
        event.preventDefault();
        const email = emailRef.current.value;
        const password = passRef.current.value;
        const result = login(email, password);
        if (result) {
            Swal.fire({
                icon: "success",
                title: "Login successful",
                text: "email or password is wrong.",
            });
            navigate('/app');
        } else {
            Swal.fire({
                icon: "error",
                title: "Login failed",
                text: "email or password is wrong.",
            });
        }
    }
    return (
        <div className='w-full flex flex-col justify-center items-center'>
            <form onSubmit={handleSubmit} className='bg-white shadow-md shadow-gray-600 w-90 p-10 rounded-md h-96'>
                <h1 className='uppercase text-3xl text-center mb-10 font-extrabold text-red-800'>Welcome back</h1>
                <section className='flex flex-col justify-center items-center'>
                    <input
                        ref={emailRef}
                        className='p-2 m-2 mb-1 rounded-sm bg-gray-200'
                        type="email"
                        placeholder='📩 Email'
                        required
                    />
                    <input
                        ref={passRef}
                        className='p-2 m-2 mb-1 rounded-sm bg-gray-200'
                        type="password"
                        placeholder='🔒 *******'
                        required
                    />
                </section>
                <section className='flex justify-around  gap-2 mt-5'>
                    <button className='cursor-pointer p-2 px-10  rounded-sm text-white bg-red-400 shadow-md hover:shadow-sm w-auto' type='submit'>login</button>
                    <button className='cursor-pointer p-2 px-10 rounded-sm text-white bg-red-400 shadow-md hover:shadow-sm w-auto' type='reset'>reset</button>
                </section>
                <div className='text-xs mt-5 text-center text-gray-500'>
                    Not a member ? <Link to="/register" className='text-blue-500 underline capitalize'>create a new account.</Link>
                </div>
            </form>
        </div>
    )
}
