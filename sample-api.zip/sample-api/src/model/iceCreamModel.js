const { readJSON, writeJSON } = require("../utils/jsonUtil");

class IceCreamModel {
  async create(newObj) {
    const data = await readJSON();
    data.push(newObj);
    await writeJSON(data);
  }
  async getAll() {
    const data = await readJSON();
    return data;
  }
  async getByFilter(key, value) {
    const data = await readJSON();
    const result = data.filter((obj) => obj[key] === value);
    return result;
  }
  async getById(id) {
    const data = await readJSON();
    const found = data.find((obj) => obj.id === id);
    if(found !== undefined) {
      return found;
    }else{
      throw new Error("ice-cream with id not found.");
    }
  }
  async update(id, key, value) {
    let data = await readJSON();
    const found = data.find((obj) => obj.id === id);
    if (found !== undefined) {
      data = data.map((obj) => {
        if (obj.id === id) {
          obj[key] = value;
        }
        return obj;
      });
      await writeJSON(data);
    } else {
      throw new Error("item with id not found");
    }
  }
  async delete(id) {
    let data = await readJSON();
    const found = data.find((obj) => obj.id === id);
    if (found !== undefined) {
      data = data.filter((obj) => obj.id !== id);
      await writeJSON(data);
    } else {
      throw new Error("item with id not found");
    }
  }
}

module.exports = IceCreamModel;
