const express = require('express');
const iceCreamRouter = require('./routes/iceCreamRoutes');

const app = express();

app.use(express.json());

app.use('/ice-cream', iceCreamRouter);
app.get("/",(req,res)=>{
   res.send("Welcome to my ice-cream API");
});


module.exports = app;