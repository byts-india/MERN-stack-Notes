const IceCreamModel = require("../model/iceCreamModel");

const iceCreamModel = new IceCreamModel();

async function create(payload) {
  const { name, flavor, price, inStock, rating } = payload;
  // validating
  for(let item of [ name, flavor, price, inStock, rating ]) {
     if(item === undefined || item === null) {
        throw new Error("Invalid payload field");
     }
  }
  const id = parseInt(Math.random()*1000);
  const newObj = { id, name, flavor, price, inStock, rating };
  await iceCreamModel.create(newObj);
}
async function getAll() {
  const result = await iceCreamModel.getAll();
  return result;
}
async function getById(id) {
  if (typeof id !== "number") {
    throw new Error("id Type is not a number");
  }
  if (id <= 0) {
    throw new Error("id should be greater than 0");
  }
  const result = await iceCreamModel.getById(id);
  return result;
}
async function update(id, payload) {
  if (typeof id !== "number") {
    throw new Error("id Type is not a number");
  }
  if (id <= 0) {
    throw new Error("id should be greater than 0");
  }
  for (let key in payload) {
    await iceCreamModel.update(id, key, payload[key]);
  }
}
async function deleteItem(id) {
  if (typeof id !== "number") {
    throw new Error("id Type is not a number");
  }
  if (id <= 0) {
    throw new Error("id should be greater than 0");
  }
  await iceCreamModel.delete(id);
}

module.exports = { getAll, getById, update, deleteItem, create };
