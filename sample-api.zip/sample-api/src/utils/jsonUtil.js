const fs = require('fs').promises;

async function readJSON() {
	try {
		const data = await fs.readFile('ice-cream.json');
		return JSON.parse(data);
	} catch (error) {
		console.error(error);
        throw new Error('something went wrong during reading JSON');
	}
}
	
async function writeJSON(data) {
	try {
		await fs.writeFile('ice-cream.json',JSON.stringify(data));
	} catch (error) {
		console.error(error);
        throw new Error('something went wrong during writing JSON');
	}
}

// WRITE THIS LINE AT END OF JSON UTILS
module.exports = { readJSON, writeJSON };