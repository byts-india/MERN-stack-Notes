const express = require('express');
const iceCreamController = require('../controller/iceCreamController');

const router = express.Router();

router.post('/', iceCreamController.create);
router.get('/all', iceCreamController.getAll);
router.get('/by/id/:id', iceCreamController.getById);
router.put('/:id',iceCreamController.update);
router.delete('/:id',iceCreamController.deleteItem);

module.exports = router;