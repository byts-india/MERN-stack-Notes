const iceCreamService = require("../service/iceCreamService");

async function create(req, res) {
  try {
    const payload = req.body;
    await iceCreamService.create(payload);
    res.status(201).json({
      success: true,
      message: "Created new data successfully."
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: "Internal server error.",
      error: error.message,
    });
  }
}
async function getAll(req, res) {
  try {
    const result = await iceCreamService.getAll();
    res.status(200).json({
      success: true,
      message: "retrieved the information successfully.",
      data: result,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: "Internal server error.",
      error: error.message,
    });
  }
}
async function getById(req, res) {
  try {
    const id = parseInt(req.params.id);
    const result = await iceCreamService.getById(id);
    res.status(200).json({
      success: true,
      message: "retrieved the information successfully by its id.",
      data: result,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: "Internal server error.",
      error: error.message,
    });
  }
}
async function update(req, res) {
  try {
    const id = parseInt(req.params.id);
    const payload = req.body;
    await iceCreamService.update(id, payload);
    res.status(200).json({
      success: true,
      message: "Updated the ice-cream successfully",
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: "Internal server error.",
      error: error.message,
    });
  }
}
async function deleteItem(req, res) {
  try {
    const id = parseInt(req.params.id);
    await iceCreamService.deleteItem(id);
    res.status(200).json({
      success: true,
      message: "Deleted the ice-cream with id successfully.",
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: "Internal server error.",
      error: error.message,
    });
  }
}

module.exports = { create, getAll, getById, update, deleteItem };
